O progresso da nossa interface
